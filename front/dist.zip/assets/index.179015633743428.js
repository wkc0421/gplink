import{_ as f}from"./index.vue_vue_type_script_setup_true_name_DictionaryItemEdit_lang.1790156337434.js";export{f as default};
