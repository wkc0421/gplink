import{_ as f}from"./index.vue_vue_type_script_setup_true_lang.179015633743411.js";export{f as default};
