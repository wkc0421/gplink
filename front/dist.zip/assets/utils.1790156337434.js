function c(e){return(e?.success===!0||e?.status===200)&&e?.result?.success!==!1}function t(e,s){return e?.result?.message||e?.message||s}export{t as g,c as i};
