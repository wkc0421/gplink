import o from"./index.1790156337434123.js";export{o as default};
