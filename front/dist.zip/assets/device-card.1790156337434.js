const e="/assets/device-card.svg";export{e as d};
