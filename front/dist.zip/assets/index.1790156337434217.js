import{_ as f}from"./index.vue_vue_type_script_setup_true_name_Device_lang.17901563374342.js";export{f as default};
