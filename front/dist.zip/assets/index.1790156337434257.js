import{e}from"./@jetlinks-web/core.1790156337434.js";import{aV as r}from"./index.1790156337434.js";var s=r();const a=e(s);export{a as R};
