import{i as t}from"./vue-router.1790156337434.js";const{BASE_API:a}=await t("@jetlinks-web/constants"),i="/file/upload",s=`${a}${i}`;export{s as F};
