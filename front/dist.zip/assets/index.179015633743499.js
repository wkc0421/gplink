import{_ as f}from"./index.vue_vue_type_style_index_0_lang.1790156337434.js";export{f as default};
