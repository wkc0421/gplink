import{i as s}from"./vue-router.1790156337434.js";import"./instance.17901563374342.js";const{BASE_API:a}=await s("@jetlinks-web/constants"),i=/^[a-zA-Z0-9_\-]+$/,e=t=>i.test(t);export{e as i};
