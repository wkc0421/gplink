import{_ as f}from"./index.vue_vue_type_script_setup_true_lang.17901563374349.js";export{f as default};
